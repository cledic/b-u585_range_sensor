#include "main.h"
#include "arm_math.h"

#include "img.h"
#include "pallettes.h"

/* Macro implementing explicit loop unrolling */
#define UNROLL_LOOP(NUMBER, CODE) \
    if (1) \
    { \
      const size_t reps = (NUMBER) >> 3; \
      size_t i_private; \
      for (i_private = reps; i_private; --i_private) \
      { \
        CODE CODE CODE CODE CODE CODE CODE CODE \
      } \
      \
      switch ((NUMBER) - (reps << 3)) \
      { \
        case 7: CODE \
        case 6: CODE \
        case 5: CODE \
        case 4: CODE \
        case 3: CODE \
        case 2: CODE \
        case 1: CODE \
      } \
    } \
    else \
    { \
      size_t i_private; \
      for (i_private = (NUMBER); i_private; --i_private) \
      { \
        CODE \
      } \
    }

static uint16_t*palettes[]={plasma,jet,seismic,hot,viridis,hotspot,coldspot,hotcold};

//defaults
static float minDist=100.0f, maxDist=2000.0f;
static uint8_t mode=0;
static uint8_t interpolate = IMG_INTERPOLATE_ON;
static uint8_t autoscale = IMG_AUTOSCALE_ON;

//images
uint8_t thermal_image[PX_Y][PX_X];
uint16_t thermal_image_int[IMG_Y_SIZE][IMG_X_SIZE];

uint8_t scaleDist(float temp, const float scaledMax); // scaled min is 0
void interpolateBilinearNoCallBack(uint16_t newWidth, uint16_t newHeight);


void setImagePixel(uint16_t x_coord, uint16_t y_coord, float temp)
{
  uint8_t value = scaleDist(temp,255.0f);
  thermal_image[y_coord][x_coord]=value;
}

uint8_t scaleDist(float temp, const float scaledMax)
{
  float scaled_val=0.0f;

  scaled_val = temp-minDist;
  scaled_val *= scaledMax;
  scaled_val /= (maxDist-minDist);

  return (uint8_t)scaled_val;
}

void setImagePixels( float*pSrc)
{
  float ftmp[(PX_X*PX_Y)];
  
  arm_fill_f32(minDist, ftmp, (PX_X*PX_Y));
  arm_sub_f32(pSrc, ftmp, ftmp, (PX_X*PX_Y));             // ftmp = pSrc-minTemp
  arm_scale_f32(ftmp, 255.0, ftmp, (PX_X*PX_Y));          // ftmp = ftmp*255.0
  float deltaDist = 1/(maxDist-minDist);          // preparo il valore 1/(maxTemp-minTemp)
  arm_scale_f32(ftmp, deltaDist, ftmp, (PX_X*PX_Y));      // thermal_image  = ftmp * (1/(maxTemp-minTemp))

  uint8_t*pDst = &thermal_image[0][0];

#if 0  
  for( int i=0; i<(PX_X*PX_Y); i++)
  { 
    pDst[i] = (uint8_t)ftmp[i];
  } 
#else
  int i=0;
  UNROLL_LOOP((PX_X*PX_Y),
    pDst[i] = (uint8_t)ftmp[i];
    i++;
  );
#endif  
}

uint16_t getImagePixel(uint16_t x_coord, uint16_t y_coord)
{
  if(interpolate)
  {
    return thermal_image_int[y_coord][x_coord];
  } else {
    return thermal_image[y_coord][x_coord];
  }
}

uint16_t*getImageRaw(uint16_t y_coord)
{
    return &thermal_image_int[y_coord][0];
}

//----------------------------------------------------------------------
void setInterpolate(uint8_t intp)
{
  interpolate=intp;
}

uint8_t getInterpolate(void)
{
  return interpolate;
}
//----------------------------------------------------------------------
void setAutoscale(uint8_t as)
{
  autoscale=as;
}

uint8_t getAutoscale(void)
{
  return autoscale;
}
//----------------------------------------------------------------------
void setColorMode(uint8_t cm)
{
  mode=cm;
}
//----------------------------------------------------------------------
uint8_t getColorMode(void)
{
  return mode;
}
//----------------------------------------------------------------------
void setMinDist(float minD)
{
  minDist=minD;
}

float getMinDist(void)
{
  return minDist;
}
//----------------------------------------------------------------------
void setMaxDist(float maxD)
{
  maxDist=maxD;
}

float getMaxDist(void)
{
  return maxDist;
}

//----------------------------------------------------------------------
uint16_t getPixelColor(uint8_t value)
{
  uint16_t*ptmp = palettes[mode];

  return ptmp[value];
}

void interpolateBilinear(uint16_t distance[IMG_Y_SIZE][IMG_X_SIZE], uint16_t newWidth, uint16_t newHeight)
{
  float a,b,c,d, tmp;
  int x,y,i,j;
  float tx = (float)(PX_X-1)/newWidth;
  float ty = (float)(PX_Y-1)/newHeight;
  float x_diff, y_diff;
  uint16_t*ptmp=palettes[mode];
  volatile uint16_t swpColor;
  
  for(i=0; i<newHeight; i++)
  {
	for(j=0; j<newWidth; j++)
	{
	  x = (int)(tx * j);
	  y = (int)(ty * i);

	  x_diff = ((tx * j) -(float)x);
	  y_diff = ((ty * i) -(float)y );

	  a = (float)(thermal_image[y][x]);
	  b = (float)(thermal_image[y][x+1]);
	  c = (float)(thermal_image[y+1][x]);
	  d = (float)(thermal_image[y+1][x+1]);

	  tmp=a*(1-x_diff)*(1-y_diff);
	  tmp+=b*(1-y_diff)*(x_diff);
	  tmp+=c*(y_diff)*(1-x_diff);
	  tmp+=d*(y_diff)*(x_diff);

	  swpColor = ptmp[(uint8_t)tmp];
	  thermal_image_int[i][j]=((swpColor&0xFF00)>>8) | ((swpColor&0xFF)<<8);
	  distance[i][j]=((swpColor&0xFF00)>>8) | ((swpColor&0xFF)<<8);
	}
  }
}
//----------------------------------------------------------------------
//----------------------------------------------------------------------
