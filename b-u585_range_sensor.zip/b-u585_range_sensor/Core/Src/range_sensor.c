/**

*/

/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "range_sensor.h"

#define POLLING_PERIOD (250U) /* milliseconds */

/* Private variables ---------------------------------------------------------*/
static RANGING_SENSOR_Capabilities_t Cap;
static RANGING_SENSOR_ProfileConfig_t Profile;

/* Private function prototypes -----------------------------------------------*/
static void print_result(RANGING_SENSOR_Result_t *Result);
static void print_resultCSV(RANGING_SENSOR_Result_t *Result);

/**
  * @brief  Ranging sensor demo
  * @param  None
  * @retval 0 if ok, else value < 0.
  */
int32_t RangingSensor_Init(void)
{
  int32_t                   result  = 0;
  uint32_t                  chipId;

  if (BSP_RANGING_SENSOR_Init(VL53L5A1_DEV_CENTER) != BSP_ERROR_NONE) result--;
  if (BSP_RANGING_SENSOR_ReadID(VL53L5A1_DEV_CENTER, &chipId) != BSP_ERROR_NONE) result--;
  if (BSP_RANGING_SENSOR_GetCapabilities(VL53L5A1_DEV_CENTER, &Cap) != BSP_ERROR_NONE) result--;

  Profile.RangingProfile   	= RS_PROFILE_8x8_CONTINUOUS;
  Profile.TimingBudget 		= 30; /* 5 ms < TimingBudget < 100 ms */
  Profile.Frequency 		= 7; /* Hz */
  Profile.EnableAmbient 	= 0; /* Enable: 1, Disable: 0 */
  Profile.EnableSignal 		= 0; /* Enable: 1, Disable: 0 */

  /* set the profile if different from default one */
  if (BSP_RANGING_SENSOR_ConfigProfile(VL53L5A1_DEV_CENTER, &Profile) != BSP_ERROR_NONE) result--;
  if (BSP_RANGING_SENSOR_Start(VL53L5A1_DEV_CENTER, RS_MODE_BLOCKING_CONTINUOUS) != BSP_ERROR_NONE)  result--;

  return result;
}

void RangingSensor_Print(void)
{
  uint32_t                   result  = 0;
  RANGING_SENSOR_Result_t   distance;
  
  /* GetDistance function */
  while (1)
  {
    if (BSP_RANGING_SENSOR_GetDistance(VL53L5A1_DEV_CENTER, &distance) != BSP_ERROR_NONE) result++;
    //print_result(&distance);
    print_resultCSV(&distance);
    HAL_Delay(POLLING_PERIOD);
	if (result) break;
  }

}

uint32_t RangingSensor_Get( RANGING_SENSOR_Result_t *d)
{
  uint32_t result  = 0;
  
  if (BSP_RANGING_SENSOR_GetDistance(VL53L5A1_DEV_CENTER, d) != BSP_ERROR_NONE) result++;
  
  return result;
}

void RangingSensor_GetDistance(uint32_t *distance)
{
  int8_t i, j, k, l;
  uint8_t zones_per_line;
  RANGING_SENSOR_Result_t   Result;

  if (BSP_RANGING_SENSOR_GetDistance(VL53L5A1_DEV_CENTER, &Result) != BSP_ERROR_NONE) return;

  zones_per_line = ((Profile.RangingProfile == RS_PROFILE_8x8_AUTONOMOUS) ||
         (Profile.RangingProfile == RS_PROFILE_8x8_CONTINUOUS)) ? 8 : 4;

  i=0;
  for (j = 0; j < Result.NumberOfZones; j += zones_per_line)
  {
    for (l = 0; l < RANGING_SENSOR_NB_TARGET_PER_ZONE; l++)
    {
      /* Print distance and status */
      for (k = (zones_per_line - 1); k >= 0; k--)
      {
        //printf("%5ld ", (long)Result->ZoneResult[j+k].Distance[l]);
		distance[i++] = Result.ZoneResult[j+k].Distance[l];
      }
    }
  }
}

static void print_result(RANGING_SENSOR_Result_t *Result)
{
  int8_t i, j, k, l;
  uint8_t zones_per_line;

  zones_per_line = ((Profile.RangingProfile == RS_PROFILE_8x8_AUTONOMOUS) ||
         (Profile.RangingProfile == RS_PROFILE_8x8_CONTINUOUS)) ? 8 : 4;

  printf("Cell Format :\r\n");
  for (l = 0; l < RANGING_SENSOR_NB_TARGET_PER_ZONE; l++)
  {
    printf(" %20s : %20s\r\n", "Distance [mm]", "Status");
    if ((Profile.EnableAmbient != 0) || (Profile.EnableSignal != 0))
    {
      printf(" %20s : %20s\r\n", "Signal [kcps/spad]", "Ambient [kcps/spad]");
    }
  }

  printf("\r\n\r\n");

  for (j = 0; j < Result->NumberOfZones; j += zones_per_line)
  {
    for (i = 0; i < zones_per_line; i++) /* number of zones per line */
      printf(" ------------------");

    printf("\r\n");

    for (i = 0; i < zones_per_line; i++)
      printf("|                  ");
    printf("|\r\n");

    for (l = 0; l < RANGING_SENSOR_NB_TARGET_PER_ZONE; l++)
    {
      /* Print distance and status */
      for (k = (zones_per_line - 1); k >= 0; k--)
      {
        if (Result->ZoneResult[j+k].NumberOfTargets > 0)
          printf("| %5ld  :  %5ld ",
              (long)Result->ZoneResult[j+k].Distance[l],
              (long)Result->ZoneResult[j+k].Status[l]);
        else
          printf("| %5s  :  %5s ", "X", "X");
      }
      printf("|\r\n");

      if ((Profile.EnableAmbient != 0) || (Profile.EnableSignal != 0))
      {
        /* Print Signal and Ambient */
        for (k = (zones_per_line - 1); k >= 0; k--)
        {
          if (Result->ZoneResult[j+k].NumberOfTargets > 0)
          {
            if (Profile.EnableSignal != 0)
              printf("| %5ld  :  ", (long)Result->ZoneResult[j+k].Signal[l]);
            else
              printf("| %5s  :  ", "X");

            if (Profile.EnableAmbient != 0)
              printf("%5ld ", (long)Result->ZoneResult[j+k].Ambient[l]);
            else
              printf("%5s ", "X");
          }
          else
            printf("| %5s  :  %5s ", "X", "X");
        }
        printf("|\r\n");
      }
    }
  }

  for (i = 0; i < zones_per_line; i++)
    printf(" ------------------");
  printf("\r\n");
}

static void print_resultCSV(RANGING_SENSOR_Result_t *Result)
{
  int8_t i, j, k, l;
  uint8_t zones_per_line;

  zones_per_line = ((Profile.RangingProfile == RS_PROFILE_8x8_AUTONOMOUS) ||
         (Profile.RangingProfile == RS_PROFILE_8x8_CONTINUOUS)) ? 8 : 4;

  printf("OK00,");
  for (j = 0; j < Result->NumberOfZones; j += zones_per_line)
  {
    for (l = 0; l < RANGING_SENSOR_NB_TARGET_PER_ZONE; l++)
    {
      /* Print distance and status */
      for (k = (zones_per_line - 1); k >= 0; k--)
      {
        printf("%6ld, ", (long)Result->ZoneResult[j+k].Distance[l]);
      }
      printf("\r\n");
    }
  }
}
