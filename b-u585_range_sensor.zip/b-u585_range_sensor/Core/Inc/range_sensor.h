#ifndef RANGE_SENSOR_H
#define RANGE_SENSOR_H

int32_t RangingSensor_Init(void);
void RangingSensor_Print(void);
uint32_t RangingSensor_Get( RANGING_SENSOR_Result_t *d);
void RangingSensor_GetDistance(uint32_t *distance);

#endif
