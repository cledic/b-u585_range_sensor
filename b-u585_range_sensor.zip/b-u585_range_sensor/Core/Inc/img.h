#ifndef IMG_H
#define IMG_H

#include <stdint.h>
#include <math.h>

#define PX_SIZE    20        //size of image pixel
#define PX_X    8        //fixed (vl53I5cx)
#define PX_Y    8        //fixed (vl53I5cx)
#define INT_POINTS  2       //PX_SIZE/INT_POINTS is image pixel size if interpolation is used
#define IMG_X_SIZE  (PX_X*PX_SIZE)  //
#define IMG_Y_SIZE  (PX_Y*PX_SIZE)  //

#define IMG_INTERPOLATE_ON    (1)
#define IMG_INTERPOLATE_OFF   (0)

#define IMG_AUTOSCALE_ON      (1)
#define IMG_AUTOSCALE_OFF     (0)

//----------------------------------------------------------------------
void setImagePixel(uint16_t x_coord, uint16_t y_coord, float temp);
void setImagePixels( float*pSrc);
uint16_t getImagePixel(uint16_t x_coord, uint16_t y_coord);
uint16_t*getImageRaw(uint16_t y_coord);
//----------------------------------------------------------------------
void setInterpolate(uint8_t intp);
uint8_t getInterpolate(void);
//----------------------------------------------------------------------
void setAutoscale(uint8_t as);
uint8_t getAutoscale(void);
//----------------------------------------------------------------------
void setColorMode(uint8_t cm);
uint8_t getColorMode(void);
//----------------------------------------------------------------------
void setMinDist(float minD);
float getMinDist(void);
//----------------------------------------------------------------------
void setMaxDist(float maxD);
float getMaxDist(void);
//----------------------------------------------------------------------
uint16_t getPixelColor(uint8_t value);
//----------------------------------------------------------------------
void interpolateBilinear(uint16_t distance[IMG_Y_SIZE][IMG_X_SIZE], uint16_t newWidth, uint16_t newHeight);
//----------------------------------------------------------------------

#endif
